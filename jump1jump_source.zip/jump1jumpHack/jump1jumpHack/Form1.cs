﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ProcessMemoryReaderLib;
using System.Runtime.InteropServices;
using System.Threading;
using System.Diagnostics;
using System.ComponentModel;

namespace jump1jumpHack
{
    public partial class Form1 : Form
    {
        double refDist = 220.553848300137;
        double refTime = 0.880;
        double velocity;
        bool activated = false;
        bool debug = false;
        bool recording = false;
        Point pointMe, pointDest;
        Stopwatch watch = new Stopwatch();

        public const int InputMouse = 0;

        public const int MouseEventMove = 0x01;
        public const int MouseEventLeftDown = 0x02;
        public const int MouseEventLeftUp = 0x04;
        public const int MouseEventRightDown = 0x08;
        public const int MouseEventRightUp = 0x10;
        public const int MouseEventAbsolute = 0x8000;

        internal struct MouseInput
        {
            public int X;
            public int Y;
            public uint MouseData;
            public uint Flags;
            public uint Time;
            public IntPtr ExtraInfo;
        }

        internal struct Input
        {
            public int Type;
            public MouseInput MouseInput;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct POINT
        {
            public int X;
            public int Y;

            public static implicit operator Point(POINT point)
            {
                return new Point(point.X, point.Y);
            }
        }
        [DllImport("user32.dll")]
        public static extern bool GetCursorPos(out POINT lpPoint);

        [DllImport("user32.dll", SetLastError = true)]
        static extern uint SendInput(uint nInputs, ref Input pInputs, int cbSize);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern uint SendInput(uint numInputs, Input[] inputs, int size);
        public Form1()
        {
            InitializeComponent();
            velocity = refDist / refTime;
            AddMessage("欢迎来到Miska辅助 v1.0 免费版");
            AddMessage("The current ref velocity is " + velocity + " px/sec");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            activated = !activated;
            if (activated)
            {
                button1.Text = "已激活";
            } else
            {
                button1.Text = "激活";
            }
            AddMessage("辅助状态被改变");
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (activated)
            {
                
                int res = ProcessMemoryReaderApi.GetKeyState(0x02);
                if (((res & 0x8000) != 0))
                {
                    label5.Text = "pressing";
                    if (pointMe.X == 0 && pointMe.Y == 0)
                    {
                        pointMe = GetCursorPosition();
                        AddMessage("_pointerMe has been changed to X:" + pointMe.X + " Y: " + pointMe.Y);
                    } else
                    {
                        pointDest = GetCursorPosition();
                        AddMessage("_pointerDest has been changed to X:" + pointDest.X + " Y: " + pointDest.Y);
                        AddMessage(CalculateDistance(pointMe, pointDest).ToString());
                        AddMessage("Now you can press [Tab] to run the hack!");
                    }
                    
                } else
                {
                    label5.Text = "not pressing";
                }
            }
        }

        public static Point GetCursorPosition()
        {
            POINT lpPoint;
            GetCursorPos(out lpPoint);
            //bool success = User32.GetCursorPos(out lpPoint);
            // if (!success)

            return lpPoint;
        }

        public void AddMessage(string msg)
        {
            richTextBox1.Text += msg + '\n';
        }

        public void RunHack()
        {
            if (pointMe.X == 0 || pointDest.X == 0)
            {
                pointMe = new Point();
                pointDest = new Point();
                return;
            }
            double distance = CalculateDistance(pointMe, pointDest);
            double cTime = (distance / velocity);
            //AddMessage("Distance: " + distance + ". You should hold for " + (cTime) + " secs and then jump");
            Input down = new Input();
            Input  up = new Input();
            Stopwatch watch2 = new Stopwatch();
            // move the mouse to the position specified
            down = new Input();
            watch2.Start();
            down.Type = InputMouse;
            down.MouseInput.Flags = MouseEventAbsolute | MouseEventLeftDown;

            SendInput(1, ref down, Marshal.SizeOf(new Input()));
            watch2.Start();
            while ((watch2.ElapsedMilliseconds) < cTime * 1000)
            {
                // something
                //SendInput(1, ref down, Marshal.SizeOf(new Input()));
            }
            watch2.Stop();
            //AddMessage("Timer 2 passed! " + watch2.ElapsedMilliseconds);
            up.Type = InputMouse;
            up.MouseInput.Flags = MouseEventAbsolute | MouseEventLeftUp;
            SendInput(1, ref up, Marshal.SizeOf(new Input()));
            AddMessage(watch2.ElapsedMilliseconds.ToString());

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (!activated || !debug)
            {
                return;
            }
            int res = ProcessMemoryReaderApi.GetKeyState(0x01);
            if (((res & 0x8000) != 0))
            {
                if (!recording)
                {
                    AddMessage("Record has began....");
                    recording = true;
                    watch.Start();
                }
            } else
            {
                if (recording)
                {
                    recording = false;
                    watch.Stop();
                    AddMessage("Record has finished execution. \nTime elapsed: " + watch.ElapsedMilliseconds);
                }
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            // Jump
            if (!activated)
            {
                return;
            }
            int res = ProcessMemoryReaderApi.GetKeyState(0x09);
            if (((res & 0x8000) != 0))
            {
                RunHack();
                pointMe = new Point();
                pointDest = new Point();
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("辅助由Miska提供", "About");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public double CalculateDistance(Point me, Point dest)
        {
            return Math.Sqrt(Math.Pow((dest.X - me.X), 2) + Math.Pow((dest.Y - me.Y), 2));
        }
    }
}
